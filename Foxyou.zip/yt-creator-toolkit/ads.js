// Foxyou ads — free with ads model.
// These are HOUSE ads (placeholders) shown only on Foxyou's own pages (popup / All Tools).
// No third-party ad code, no tracking, no data sent anywhere.
// To run real paid ads later, replace the ADS list below with your ad provider's
// approved creative / link — see README "Ads" section first (Chrome Web Store ad rules apply).
const FOXYOU_ADS = [
  { title: 'Foxyou — 42 free YouTube tools', text: 'Channel analytics, Shorts, outliers, thumbnails and more — free, right in your browser.', link: 'https://www.youtube.com/' },
  { title: 'Your brand here', text: 'Reach YouTube creators using Foxyou. This slot is available for sponsors.', link: 'https://www.youtube.com/' },
  { title: 'Tip from Foxyou', text: 'Add your own YouTube Data API key in Options to unlock full channel and video analytics.', link: '' },
];
function renderFoxyouAd(el) {
  if (!el) return;
  const i = (new Date().getDate() + new Date().getHours()) % FOXYOU_ADS.length;
  const ad = FOXYOU_ADS[i];
  el.innerHTML = '<div style="border:1px solid #ddd;border-radius:10px;padding:10px;background:#fff8e1"><small style="color:#666">Sponsored — Foxyou is free with ads</small><br><b>' + ad.title + '</b><br>' + ad.text + (ad.link ? '<br><a href="' + ad.link + '" target="_blank">Learn more</a>' : '') + '</div>';
}
