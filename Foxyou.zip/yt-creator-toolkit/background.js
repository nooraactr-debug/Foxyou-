// Foxyou — background service worker.
// All API calls go through here. No tracking, no external server of ours.
// The user enters their OWN YouTube Data API v3 key in Options; it is stored
// only in chrome.storage.local on their device and is never shipped in code.
const YT = 'https://www.googleapis.com/youtube/v3';

async function getKey() {
  const r = await chrome.storage.local.get(['ytApiKey']);
  return r.ytApiKey || '';
}
function num(n) { const v = Number(n || 0); return isFinite(v) ? v : 0; }
function fmt(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return String(n);
}
async function yt(path, params) {
  const key = await getKey();
  if (!key) return { error: 'NO_API_KEY' };
  const q = new URLSearchParams({ ...params, key });
  const res = await fetch(`${YT}/${path}?${q}`);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { error: data.error?.message || 'YouTube API error', status: res.status };
  return data;
}
async function channelByHandleOrId(input) {
  // input can be @handle, channel ID (UC...), or a channel URL fragment
  const h = (input || '').trim();
  if (/^UC[\w-]{20,}$/.test(h)) {
    const d = await yt('channels', { part: 'snippet,statistics', id: h });
    return d.items?.[0] || null;
  }
  let rest = h.replace(/^https?:\/\/(www\.)?youtube\.com\//, '');
  if (/^UC[\w-]{20,}$/.test(rest.replace(/^channel\//, ''))) { const d = await yt('channels', { part: 'snippet,statistics', id: rest.replace(/^channel\//, '') }); return d.items?.[0] || null; }
  rest = rest.replace(/^(channel\/|c\/|user\/|@)/, '');
  const handle = rest.split('/')[0].replace(/^@/, '');
  const d = await yt('channels', { part: 'snippet,statistics', forHandle: '@' + handle });
  if (d.items?.[0]) return d.items[0];
  const s = await yt('search', { part: 'snippet', type: 'channel', q: handle, maxResults: 1 });
  if (s.items?.[0]?.id?.channelId) {
    const c = await yt('channels', { part: 'snippet,statistics', id: s.items[0].id.channelId });
    return c.items?.[0] || null;
  }
  return null;
}
async function recentVideos(channelId, max = 25) {
  const ch = await yt('channels', { part: 'contentDetails', id: channelId });
  const uploads = ch.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
  if (!uploads) return [];
  const pl = await yt('playlistItems', { part: 'contentDetails', playlistId: uploads, maxResults: Math.min(50, max) });
  const ids = (pl.items || []).map(i => i.contentDetails.videoId).filter(Boolean);
  if (!ids.length) return [];
  const v = await yt('videos', { part: 'snippet,statistics,contentDetails', id: ids.join(',') });
  return v.items || [];
}
function analyseVideos(videos) {
  const views = videos.map(v => num(v.statistics?.viewCount));
  const avg = views.length ? Math.round(views.reduce((a, b) => a + b, 0) / views.length) : 0;
  const sorted = [...videos].sort((a, b) => num(b.statistics?.viewCount) - num(a.statistics?.viewCount));
  return {
    count: videos.length, avgViews: avg, avgViewsFmt: fmt(avg),
    top: sorted.slice(0, 5).map(v => ({
      id: v.id, title: v.snippet?.title, views: num(v.statistics?.viewCount),
      viewsFmt: fmt(num(v.statistics?.viewCount)),
      outlier: avg ? +(num(v.statistics?.viewCount) / avg).toFixed(2) : 0,
      publishedAt: v.snippet?.publishedAt
    }))
  };
}
function durationSeconds(iso) { const m = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso || ''); if (!m) return 0; return (parseInt(m[1]||'0')*3600)+(parseInt(m[2]||'0')*60)+parseInt(m[3]||'0'); }
function viewsPerHour(views, publishedAt) {
  const hours = Math.max(1, (Date.now() - new Date(publishedAt).getTime()) / 3600e3);
  return Math.round(views / hours);
}
function sentimentScore(text) {
  const pos = ['love', 'amazing', 'great', 'awesome', 'best', 'beautiful', 'helpful', 'thanks', 'thank', 'excellent', 'fantastic', 'perfect', 'brilliant', 'inspiring', 'fun', 'good'];
  const neg = ['bad', 'worst', 'hate', 'terrible', 'awful', 'boring', 'disappointing', 'waste', 'annoying', 'fake', 'scam', 'useless', 'sad', 'angry'];
  const t = (text || '').toLowerCase();
  let s = 0;
  pos.forEach(w => { if (t.includes(w)) s++; });
  neg.forEach(w => { if (t.includes(w)) s--; });
  return s;
}
function titleScore(title) {
  let score = 0; const tips = [];
  const t = (title || '');
  if (t.length >= 30 && t.length <= 70) { score += 25; } else tips.push('Aim for 30–70 characters.');
  if (/\d/.test(t)) { score += 20; } else tips.push('Add a number — it lifts click-through.');
  if (/[?!]/.test(t)) { score += 15; }
  if (/how|why|what|secret|best|top|free|new/i.test(t)) { score += 20; } else tips.push('Add a curiosity or benefit word (how, why, secret, best).');
  if (t.trim().split(/\s+/).length >= 5) score += 20;
  return { score: Math.min(100, score), tips };
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  (async () => {
    try {
      if (msg.type === 'GET_KEY_STATUS') { send({ hasKey: !!(await getKey()) }); return; }
      if (msg.type === 'CHANNEL') {
        const ch = await channelByHandleOrId(msg.input);
        if (!ch) { send({ error: 'Channel not found. Add a YouTube Data API key in Options, or use a full channel ID.' }); return; }
        const videos = await recentVideos(ch.id, 25);
        const a = analyseVideos(videos);
        send({
          channel: {
            id: ch.id, title: ch.snippet?.title, subs: num(ch.statistics?.subscriberCount),
            subsFmt: fmt(num(ch.statistics?.subscriberCount)),
            totalViews: num(ch.statistics?.viewCount), totalViewsFmt: fmt(num(ch.statistics?.viewCount)),
            videoCount: num(ch.statistics?.videoCount), thumb: ch.snippet?.thumbnails?.default?.url
          },
          analysis: a,
          videos: videos.map(v => ({
            id: v.id, title: v.snippet?.title, views: num(v.statistics?.viewCount), viewsFmt: fmt(num(v.statistics?.viewCount)),
            vph: viewsPerHour(num(v.statistics?.viewCount), v.snippet?.publishedAt),
            outlier: a.avgViews ? +(num(v.statistics?.viewCount) / a.avgViews).toFixed(2) : 0,
            publishedAt: v.snippet?.publishedAt, duration: v.contentDetails?.duration, isShort: durationSeconds(v.contentDetails?.duration) > 0 && durationSeconds(v.contentDetails?.duration) <= 60
          }))
        });
        return;
      }
      if (msg.type === 'VIDEO') {
        const d = await yt('videos', { part: 'snippet,statistics,contentDetails', id: msg.id });
        const v = d.items?.[0];
        if (!v) { send({ error: 'Video not found or API key missing.' }); return; }
        send({
          video: {
            id: v.id, title: v.snippet?.title, channelTitle: v.snippet?.channelTitle, channelId: v.snippet?.channelId,
            views: num(v.statistics?.viewCount), viewsFmt: fmt(num(v.statistics?.viewCount)),
            likes: num(v.statistics?.likeCount), comments: num(v.statistics?.commentCount),
            vph: viewsPerHour(num(v.statistics?.viewCount), v.snippet?.publishedAt),
            publishedAt: v.snippet?.publishedAt, duration: v.contentDetails?.duration, durationSeconds: durationSeconds(v.contentDetails?.duration), isShort: durationSeconds(v.contentDetails?.duration) > 0 && durationSeconds(v.contentDetails?.duration) <= 60,
            tags: v.snippet?.tags || [], description: v.snippet?.description || ''
          }
        });
        return;
      }
      if (msg.type === 'SEARCH') {
        const d = await yt('search', { part: 'snippet', type: 'video', q: msg.q, maxResults: 10, order: 'viewCount' });
        if (d.error) { send({ error: d.error }); return; }
        send({ items: (d.items || []).map(i => ({ id: i.id.videoId, title: i.snippet?.title, channel: i.snippet?.channelTitle, publishedAt: i.snippet?.publishedAt })) });
        return;
      }
      if (msg.type === 'COMMENTS') {
        const d = await yt('commentThreads', { part: 'snippet', videoId: msg.id, maxResults: 50, order: 'relevance', textFormat: 'plainText' });
        const comments = (d.items || []).map(i => i.snippet?.topLevelComment?.snippet?.textDisplay || '');
        const scores = comments.map(sentimentScore);
        const pos = scores.filter(s => s > 0).length, neg = scores.filter(s => s < 0).length;
        send({ count: comments.length, positive: pos, negative: neg, neutral: comments.length - pos - neg, sample: comments.slice(0, 5) });
        return;
      }
      if (msg.type === 'TITLE_SCORE') { send(titleScore(msg.title)); return; }
      if (msg.type === 'TRACKED') {
        const r = await chrome.storage.local.get(['tracked']);
        send({ tracked: r.tracked || [] });
        return;
      }
      if (msg.type === 'TRACK_ADD') {
        const r = await chrome.storage.local.get(['tracked']);
        const list = r.tracked || [];
        if (!list.find(x => x.id === msg.channel.id)) list.push(msg.channel);
        await chrome.storage.local.set({ tracked: list });
        send({ ok: true, tracked: list });
        return;
      }
      if (msg.type === 'SWIPE_ADD') {
        const r = await chrome.storage.local.get(['swipe']);
        const list = r.swipe || [];
        list.unshift(msg.item);
        await chrome.storage.local.set({ swipe: list.slice(0, 200) });
        send({ ok: true });
        return;
      }

      if (msg.type === 'COMPARE_CHANNELS') {
        const a = await channelByHandleOrId(msg.a), b = await channelByHandleOrId(msg.b);
        if (!a || !b) { send({ error: 'One or both channels not found.' }); return; }
        const fmtCh = c => ({ title: c.snippet?.title, subs: fmt(num(c.statistics?.subscriberCount)), views: fmt(num(c.statistics?.viewCount)), videos: num(c.statistics?.videoCount) });
        send({ a: fmtCh(a), b: fmtCh(b) }); return;
      }
      if (msg.type === 'COMPARE_VIDEOS') {
        const d = await yt('videos', { part: 'snippet,statistics', id: [msg.a, msg.b].join(',') });
        if (d.error) { send({ error: d.error }); return; }
        const list = (d.items || []).map(v => ({ title: v.snippet?.title, views: fmt(num(v.statistics?.viewCount)), likes: num(v.statistics?.likeCount), comments: num(v.statistics?.commentCount) }));
        send({ list }); return;
      }
      if (msg.type === 'PLAYLIST') {
        const pl = await yt('playlistItems', { part: 'contentDetails', playlistId: msg.id, maxResults: 50 });
        if (pl.error) { send({ error: pl.error }); return; }
        const ids = (pl.items || []).map(i => i.contentDetails.videoId).filter(Boolean);
        const v = await yt('videos', { part: 'snippet,statistics', id: ids.join(',') });
        const vs = (v.items || []).map(x => num(x.statistics?.viewCount));
        const avg = vs.length ? Math.round(vs.reduce((a,b)=>a+b,0)/vs.length) : 0;
        send({ count: ids.length, total: fmt(vs.reduce((a,b)=>a+b,0)), avg: fmt(avg), top: (v.items||[]).sort((a,b)=>num(b.statistics?.viewCount)-num(a.statistics?.viewCount)).slice(0,3).map(x=>x.snippet?.title) }); return;
      }
      if (msg.type === 'KEYWORD') {
        const d = await yt('search', { part: 'snippet', type: 'video', q: msg.q, maxResults: 25 });
        if (d.error) { send({ error: d.error }); return; }
        const chans = [...new Set((d.items||[]).map(i=>i.snippet?.channelTitle))];
        send({ totalResults: d.pageInfo?.totalResults || 0, channels: chans.length, channelList: chans, sample: (d.items||[]).slice(0,5).map(i=>i.snippet?.title) }); return;
      }
      if (msg.type === 'NICHE') {
        const d = await yt('search', { part: 'snippet', type: 'video', q: msg.q, maxResults: 25, order: 'viewCount' });
        if (d.error) { send({ error: d.error }); return; }
        const ids = (d.items||[]).map(i=>i.id.videoId).filter(Boolean);
        const v = await yt('videos', { part: 'statistics', id: ids.join(',') });
        const vs = (v.items||[]).map(x=>num(x.statistics?.viewCount));
        const avg = vs.length ? Math.round(vs.reduce((a,b)=>a+b,0)/vs.length) : 0;
        const distinct = [...new Set((d.items||[]).map(i=>i.snippet?.channelTitle))];
        send({ videos: vs.length, avgViews: fmt(avg), topViews: vs.length ? fmt(Math.max(...vs)) : '0', distinctChannels: distinct.length, saturation: distinct.length && vs.length ? Math.round(distinct.length / vs.length * 100) : 0, note: 'Saturation = distinct channels in top results ÷ videos analysed, as a percentage proxy only — not a private database.' }); return;
      }
      if (msg.type === 'TRANSCRIPT') {
        const res = await fetch(`https://www.youtube.com/api/timedtext?v=${encodeURIComponent(msg.id)}&lang=en&fmt=json3`);
        const txt = await res.text();
        if (!txt || txt.includes('<transcript>') === false && txt.length < 20) { send({ error: 'No published English captions found for this video.' }); return; }
        try { const j = JSON.parse(txt); const lines = (j.events||[]).filter(e=>e.segs).map(e=>e.segs.map(s=>s.utf8).join('')).filter(Boolean); if (lines.length) { send({ lines: lines.slice(0,200), count: lines.length }); return; } }
        catch {}
        const xmlLines = [...txt.matchAll(/<text[^>]*>([^<]+)<\/text>/g)].map(m => m[1].replace(/&amp;/g,'&').replace(/&#39;/g,"'").replace(/&quot;/g,'"'));
        if (xmlLines.length) { send({ lines: xmlLines.slice(0,200), count: xmlLines.length }); return; }
        send({ error: 'No published English captions found for this video.' });
        return;
      }
      if (msg.type === 'SNAPSHOT') {
        const ch = await channelByHandleOrId(msg.input); if (!ch) { send({ error: 'Channel not found.' }); return; }
        const snap = { id: ch.id, title: ch.snippet?.title, subs: num(ch.statistics?.subscriberCount), views: num(ch.statistics?.viewCount), at: new Date().toISOString() };
        const r = await chrome.storage.local.get(['snapshots']); const list = r.snapshots || [];
        const prev = [...list].reverse().find(x=>x.id===ch.id);
        list.push(snap); await chrome.storage.local.set({ snapshots: list.slice(-200) });
        send({ snap, prev: prev || null, subsChange: prev ? snap.subs - prev.subs : null, viewsChange: prev ? snap.views - prev.views : null }); return;
      }
      if (msg.type === 'DASHBOARD') {
        const r = await chrome.storage.local.get(['tracked']); const list = r.tracked || [];
        let subs = 0, views = 0; list.forEach(c=>{ subs += num(c.subs); views += num(c.totalViews); });
        send({ count: list.length, subs: fmt(subs), views: fmt(views), channels: list.map(c=>c.title) }); return;
      }
      if (msg.type === 'NOTES_SAVE') { const r = await chrome.storage.local.get(['notes']); const n = r.notes || {}; n[msg.key] = msg.text; await chrome.storage.local.set({ notes: n }); send({ ok: true }); return; }
      if (msg.type === 'NOTES_GET') { const r = await chrome.storage.local.get(['notes']); send({ text: (r.notes||{})[msg.key] || '' }); return; }
      if (msg.type === 'AUTH_STATUS') { send({ note: 'Own-channel Analytics needs an OAuth Client ID in manifest.json (client ID only, never a secret) plus chrome.identity sign-in. Without it, public analytics only — no private data is invented.' }); return; }

      if (msg.type === 'AUTH_SIGNUP') {
        const email = (msg.email || '').trim().toLowerCase();
        if (!email.includes('@') || !msg.passHash) { send({ error: 'Enter a valid email and a password.' }); return; }
        const r = await chrome.storage.local.get(['ctkUsers']); const users = r.ctkUsers || [];
        if (users.find(u => u.email === email)) { send({ error: 'An account with this email already exists on this device. Log in instead.' }); return; }
        users.push({ email, name: msg.name || '', passHash: msg.passHash, createdAt: new Date().toISOString() });
        await chrome.storage.local.set({ ctkUsers: users, ctkCurrentUser: email });
        send({ ok: true, email }); return;
      }
      if (msg.type === 'AUTH_LOGIN') {
        const email = (msg.email || '').trim().toLowerCase();
        const r = await chrome.storage.local.get(['ctkUsers']); const user = (r.ctkUsers || []).find(u => u.email === email);
        if (!user || user.passHash !== msg.passHash) { send({ error: 'Email or password does not match an account on this device.' }); return; }
        await chrome.storage.local.set({ ctkCurrentUser: email });
        send({ ok: true, email, name: user.name }); return;
      }
      if (msg.type === 'AUTH_ME') { const r = await chrome.storage.local.get(['ctkCurrentUser', 'ctkUsers']); const user = (r.ctkUsers || []).find(u => u.email === r.ctkCurrentUser); send({ email: user ? user.email : null, name: user ? user.name : '' }); return; }
      if (msg.type === 'AUTH_LOGOUT') { await chrome.storage.local.set({ ctkCurrentUser: null }); send({ ok: true }); return; }
      if (msg.type === 'AUTH_GOOGLE') {
        try {
          if (!chrome.identity || !chrome.identity.getAuthToken) throw new Error('Chrome identity is not configured for this extension.');
          const token = await new Promise((res, rej) => chrome.identity.getAuthToken({ interactive: true }, t => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(t)));
          send({ ok: true, note: 'Google sign-in token obtained. To use it for own-channel Analytics, add your own OAuth Client ID to manifest.json under "oauth2" (client ID only, never a secret) and reload the extension.' });
        } catch (e) { send({ error: 'Google sign-in is not configured yet. ' + String(e?.message || e) + ' To enable it, add your own OAuth Client ID to manifest.json under "oauth2" (client ID only, never a secret) and reload the extension.' }); }
        return;
      }
      if (msg.type === 'SWIPE_LIST') { const r = await chrome.storage.local.get(['swipe']); send({ items: r.swipe || [] }); return; }
      if (msg.type === 'SIMILAR_CHANNELS') {
        const d = await yt('search', { part: 'snippet', type: 'channel', q: msg.q, maxResults: 10 });
        if (d.error) { send({ error: d.error }); return; }
        send({ items: (d.items || []).map(i => ({ id: i.id.channelId, title: i.snippet?.title })) }); return;
      }
      send({ error: 'Unknown message' });
    } catch (e) { send({ error: String(e?.message || e) }); }
  })();
  return true;
});
