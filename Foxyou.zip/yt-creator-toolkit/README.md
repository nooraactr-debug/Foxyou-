# Foxyou — YouTube Research & Analytics (v2.0.0 — all 42 tools)

A local-first Chrome extension built from scratch. It is NOT Nexlev, does not copy Nexlev's code, branding, or private database, and does not send your browsing to any server.

## Install (unpacked, for testing)
1. Open Chrome → `chrome://extensions` → turn on **Developer mode** (top right).
2. Click **Load unpacked** → choose the `yt-foxyou` folder.
3. Click the extension icon, then **Options** → paste your own YouTube Data API v3 key (free, Google Cloud Console, YouTube Data API v3 enabled). The key is stored only in `chrome.storage.local` on your device.
4. Browse YouTube. A small Foxyou panel appears bottom-right with screenshot / thumbnail / filter tools. Use the popup for analytics.

## SECURITY — read this about the file you uploaded
You uploaded a file named `client_secret_….apps.googleusercontent.com.json`. I did **not** open it, did **not** copy anything from it, and did **not** put anything from it into this extension — on purpose.
- An OAuth client secret must never be shipped inside a Chrome extension: anyone who installs the extension can read its files and steal it.
- For a Chrome extension, own-channel OAuth uses the client ID with Chrome's identity flow, not a secret in code. For public analytics, the safe pattern is the one used here: the user enters their own API key in Options, stored locally.
- If that secret file was ever shared, posted, or put into any published code, rotate/revoke it in Google Cloud Console → APIs & Services → Credentials, and create a new one. Keep the file private on your own device only.

## Features in v1 (working, using public data + your API key)
Channel analytics, average views, top outliers, views/hour, Shorts page detection, similar/top videos by search, advanced home/search filter (dim under 10K views), thumbnail preview/download, video-frame screenshot, transcript-ready video ID handling, comment sentiment (word-list scoring, labelled as an estimate), title tester + SEO hints, tag list, net-profit / RPM calculator, tracked channels, swipe file, combined tracked list, export-ready data in the popup.

## The honest 40+ status
Nexlev advertises 40+ tools, many powered by its own private database of 100M+ channels, its AI thumbnail generator, sponsorship database, MCP server and n8n automation. Those private-database / paid-AI features cannot be replicated by an independent extension, and I will not fake them with made-up numbers.
- Implemented in v1: the research/analytics/workflow tools above (~20 core tools).
- Estimates, clearly labelled: revenue/RPM, monetization status, saturation — never presented as actual earnings.
- Not in v1 / needs a separate service: AI thumbnail generation, a 122M-channel niche finder database, sponsorship analysis from a private database, MCP/n8n automation, automatic ad placement on other people's videos (only the channel owner can do this via official Studio APIs, with their own OAuth).
- Next phases if you want them: keyword research panel, competitor tracking alerts, Shorts feed analytics overlay, thumbnail A/B preview comparison, CSV export button, dark-mode panel.

## Privacy
No account. No analytics sent anywhere. The extension only runs on youtube.com and googleapis.com (for your API key calls). Delete it from `chrome://extensions` to remove it completely.

## v2 — all 42 tools
See FEATURES.md for the full list with status. New in v2: channel/video comparison, playlist analytics, keyword & niche research, transcript copy, title/hashtag generator (template-based), growth snapshots, combined dashboard, thumbnail A/B preview, thumbnail compressor, saved notes, CSV export, and the All Tools page (popup → Open all 42 tools). Own-channel Analytics (demographics etc.) remains own-login only, via a Client ID you add yourself to manifest.json — never a secret.

## Ads — free with ads
Foxyou is free: all 42 tools are available without payment. It is supported by ads, shown only on Foxyou's own pages (popup and All Tools page), clearly labelled “Sponsored — Foxyou is free with ads”. Ads are NOT injected into YouTube pages, and the current build uses house placeholder ads only (see ads.js) — no third-party ad code and no tracking. To run real paid ads later: replace the house ads in ads.js with your approved sponsor creative, disclose ads in your Chrome Web Store listing, and check the Web Store ad policy first — some ad networks (including AdSense) have restrictions inside extensions, and a third-party ad network may track users, which would change the privacy story above. Do not claim ad revenue until a real provider is connected and approved.
