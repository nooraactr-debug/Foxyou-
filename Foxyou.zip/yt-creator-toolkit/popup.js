const out = document.getElementById('out');
const show = (x) => { out.innerHTML = ''; const d = document.createElement('div'); d.className = 'card'; d.textContent = typeof x === 'string' ? x : JSON.stringify(x, null, 2); out.appendChild(d); };
const send = (msg) => new Promise(r => chrome.runtime.sendMessage(msg, r));
chrome.runtime.sendMessage({ type: 'GET_KEY_STATUS' }, r => { if (r?.hasKey) document.getElementById('keyWarn').style.display = 'none'; });
document.getElementById('chBtn').onclick = async () => {
  const input = document.getElementById('chInput').value.trim(); if (!input) return show('Enter a channel @handle or ID.');
  show('Analysing…'); const r = await send({ type: 'CHANNEL', input });
  if (r.error) return show('Error: ' + r.error);
  show(`Channel: ${r.channel.title}\nSubscribers: ${r.channel.subsFmt} · Total views: ${r.channel.totalViewsFmt} · Videos: ${r.channel.videoCount}\nAverage views (last ${r.analysis.count}): ${r.analysis.avgViewsFmt}\nTop outliers:\n` + r.analysis.top.map(t => `• ${t.title} — ${t.viewsFmt} (${t.outlier}x avg)`).join('\n'));
  const b = document.createElement('button'); b.textContent = 'Track this channel'; b.onclick = async () => { await send({ type: 'TRACK_ADD', channel: r.channel }); show('Tracked. See it in the combined dashboard on the All Tools page.'); }; out.appendChild(b);
  const c = document.createElement('button'); c.textContent = 'Save to swipe file'; c.onclick = async () => { await send({ type: 'SWIPE_ADD', item: { title: r.channel.title, id: r.channel.id } }); show('Saved to swipe file.'); }; out.appendChild(c);
};
document.getElementById('vidBtn').onclick = async () => {
  const id = document.getElementById('vidInput').value.trim(); if (!id) return show('Enter a video ID.');
  show('Analysing…'); const r = await send({ type: 'VIDEO', id });
  if (r.error) return show('Error: ' + r.error);
  const v = r.video;
  show(`Video: ${v.title}\nChannel: ${v.channelTitle}\nViews: ${v.viewsFmt} · Likes: ${v.likes} · Comments: ${v.comments}\nViews/hour: ${v.vph}\nDuration: ${v.duration || ''} (${v.durationSeconds || 0}s)${v.isShort ? ' — Short (≤60s)' : ''}\nTags: ${(v.tags || []).join(', ') || 'none'}`);
  const b = document.createElement('button'); b.textContent = 'Comment sentiment'; b.onclick = async () => { const c = await send({ type: 'COMMENTS', id }); show(c.error ? c.error : `Comments analysed: ${c.count}\nPositive: ${c.positive} · Negative: ${c.negative} · Neutral: ${c.neutral}`); }; out.appendChild(b);
};
document.getElementById('searchBtn').onclick = async () => {
  const q = document.getElementById('searchInput').value.trim(); if (!q) return show('Enter a topic.');
  show('Searching…'); const r = await send({ type: 'SEARCH', q });
  if (r.error) return show('Error: ' + r.error);
  show('Similar / top videos by views:\n' + (r.items || []).map(i => `• ${i.title} — ${i.channel}`).join('\n'));
};
document.getElementById('titleBtn').onclick = async () => {
  const title = document.getElementById('titleInput').value.trim(); if (!title) return show('Enter a title.');
  const r = await send({ type: 'TITLE_SCORE', title });
  show(`Title score: ${r.score}/100\n${r.tips.join('\n') || 'Strong title.'}`);
};
document.getElementById('profitBtn').onclick = () => {
  const rpm = +document.getElementById('rpm').value, views = +document.getElementById('pViews').value, cost = +document.getElementById('cost').value;
  const revenue = views / 1000 * rpm, profit = revenue - cost;
  show(`Revenue estimate: $${revenue.toFixed(2)}\nCosts: $${cost.toFixed(2)}\nNet profit estimate: $${profit.toFixed(2)}\nNote: RPM varies by niche and geography — this is an estimate, not actual earnings.`);
};
document.getElementById('openOptions').onclick = (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); };
document.getElementById('openYT').onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: 'https://www.youtube.com/' }); };

document.getElementById('allTools').onclick = () => { chrome.tabs.create({ url: chrome.runtime.getURL('tools.html') }); };

async function sha256Hex(text) { const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)); return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join(''); }
async function refreshAuth() { const r = await send({ type: 'AUTH_ME' }); const el = document.getElementById('authStatus'); if (el) el.textContent = r.email ? `Logged in as ${r.name || r.email} (${r.email})` : 'Not logged in. Login is optional — tools work without it, but your saved items are tied to your account on this device.'; }
document.getElementById('authSignup').onclick = async () => { const email = document.getElementById('authEmail').value.trim(), name = document.getElementById('authName').value.trim(), pass = document.getElementById('authPass').value; if (!pass) return show('Enter a password to sign up.'); const r = await send({ type: 'AUTH_SIGNUP', email, name, passHash: await sha256Hex(pass) }); show(r.error ? 'Sign up error: ' + r.error : 'Welcome to Foxyou, ' + (name || email) + '! You are signed up and logged in on this device.'); refreshAuth(); };
document.getElementById('authLogin').onclick = async () => { const email = document.getElementById('authEmail').value.trim(), pass = document.getElementById('authPass').value; const r = await send({ type: 'AUTH_LOGIN', email, passHash: await sha256Hex(pass) }); show(r.error ? 'Log in error: ' + r.error : 'Welcome back to Foxyou, ' + (r.name || email) + '!'); refreshAuth(); };
document.getElementById('authLogout').onclick = async () => { await send({ type: 'AUTH_LOGOUT' }); show('Logged out of Foxyou on this device.'); refreshAuth(); };
document.getElementById('authGoogle').onclick = async () => { const r = await send({ type: 'AUTH_GOOGLE' }); show(r.error ? r.error : r.note); };
refreshAuth();

renderFoxyouAd(document.getElementById('foxyouAd'));
