// Foxyou — content script, runs only on youtube.com, only when you browse it.
// It reads the public page you are already viewing. It sends nothing to any server of ours.
(function () {
  if (window.__ctk) return; window.__ctk = true;
  const panel = document.createElement('div'); panel.id = 'ctk-panel';
  panel.innerHTML = `<b>Foxyou</b><span id="ctk-body">Loading page data…</span><button id="ctk-shot">Screenshot video frame</button><button id="ctk-thumb">Download thumbnail</button><button id="ctk-filter">Filter: hide low-view videos</button>`;
  function mount() { if (!document.getElementById('ctk-panel')) document.body.appendChild(panel); }
  setInterval(mount, 2000); mount();
  function videoId() { const m = location.href.match(/[?&]v=([\w-]{11})/); return m ? m[1] : null; }
  function isShort() { return location.pathname.startsWith('/shorts/'); }
  function update() {
    const body = document.getElementById('ctk-body'); if (!body) return;
    const vid = videoId() || (isShort() ? location.pathname.split('/')[2] : null);
    const title = document.querySelector('h1 yt-formatted-string')?.textContent || document.title;
    body.textContent = vid ? ` ${isShort() ? 'Short' : 'Video'}: ${vid} — ${title}` : ` Page: ${location.pathname} — use the popup for full channel/video analytics.`;
  }
  setInterval(update, 2000); update();
  document.addEventListener('click', (e) => {
    if (e.target.id === 'ctk-shot') {
      const v = document.querySelector('video'); if (!v) return alert('No video playing on this page.');
      const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
      c.getContext('2d').drawImage(v, 0, 0);
      const a = document.createElement('a'); a.download = 'video-frame.png'; a.href = c.toDataURL('image/png'); a.click();
    }
    if (e.target.id === 'ctk-thumb') {
      const vid = videoId() || (isShort() ? location.pathname.split('/')[2] : null); if (!vid) return alert('Open a video or Short first.');
      const a = document.createElement('a'); a.download = vid + '-thumbnail.jpg'; a.href = `https://i.ytimg.com/vi/${vid}/maxresdefault.jpg`; a.target = '_blank'; a.click();
    }
    if (e.target.id === 'ctk-filter') {
      // Simple, transparent filter: hide video cards whose view text is under 10K, on home/search pages.
      document.querySelectorAll('ytd-video-renderer, ytd-rich-item-renderer, ytd-compact-video-renderer').forEach(el => {
        const t = el.textContent || ''; const m = t.match(/([\d.]+)K views|([\d.]+)M views/) || t.match(/([\d,]+) views/);
        const views = m ? (m[2] ? parseFloat(m[2]) * 1e6 : (m[1].includes('K') || t.includes('K views') ? parseFloat(m[1]) * 1e3 : parseFloat(m[1].replace(/,/g, '')))) : 0;
        if (views && views < 10000) el.style.opacity = '0.25';
      });
      alert('Filter applied: videos under 10K views are dimmed on this page. Reload to reset.');
    }
  });
})();
