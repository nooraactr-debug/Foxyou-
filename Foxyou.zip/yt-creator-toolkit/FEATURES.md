# Foxyou — Full Feature List (42 tools, v2)

Status key:
- DONE = works in this extension with public data + your own YouTube Data API key in Options
- EST = a calculation/estimate, clearly labelled in the UI, never presented as actual earnings or private data
- OWN = only for a channel you own, after you add your own OAuth Client ID to manifest.json (client ID only, never a secret) and sign in via Chrome identity. Without that login it explains why it is unavailable instead of inventing data.

## Analytics
1. Channel analytics — DONE
2. Video analytics — DONE
3. Shorts analytics (Shorts detected by URL, duration < 60s) — DONE
4. Combined multi-channel dashboard (tracked channels, summed subs/views) — DONE
5. Average views, subscriber count, total views — DONE
6. Outlier detection (video views ÷ channel average) — DONE
7. Views per hour — DONE
8. Growth snapshots (save a channel snapshot, compare later) — DONE
9. Channel comparison (two channels side by side) — DONE
10. Video comparison (two videos side by side) — DONE
11. Playlist analytics (average, total, top video) — DONE
12. Trending / top videos by search — DONE
13. Best posting-time estimate (hour distribution of top videos) — EST
14. Audience demographics — OWN only (YouTube Analytics API, owner login required; public channels: not available, and no data is invented)
15. Monetization-status estimate (subs/views thresholds) — EST
16. Saturation score estimate (search competition proxy) — EST
17. RPM / revenue estimate — EST
18. Net profit calculator — DONE (your RPM, views and costs)

## Research
19. Similar channels (by keyword/category search) — DONE
20. Similar videos — DONE
21. Similar thumbnails grid — DONE
22. Keyword research (search volume proxy = total results, top channels) — EST
23. Niche analysis (aggregate a topic: avg views, channel count, outlier rate) — DONE/EST
24. Competitor tracking (tracked channels + snapshot history) — DONE
25. Outlier finder for a topic — DONE
26. Swipe file (save titles/thumbnails/channels) — DONE
27. Tag extractor (from a video) — DONE
28. Description analyser (length, links, keywords) — DONE
29. Title generator (template-based, from a keyword — not AI) — DONE
30. Hashtag generator (from title/tags) — DONE
31. Comment sentiment — DONE (word-list scoring, labelled estimate)
32. Transcript copy (captions if the video publishes them, otherwise a clear “not available”) — DONE

## On-page workflow (YouTube pages)
33. Advanced home/search/subscription filters (dim low-view videos, keyword filter) — DONE
34. Shorts feed overlay (panel on Shorts pages) — DONE
35. Thumbnail preview and download — DONE
36. Video-frame screenshot — DONE
37. Thumbnail A/B preview (two video IDs side by side) — DONE
38. Thumbnail compressor (upload an image, compress to JPEG in-browser) — DONE
39. Title/thumbnail tester (score + preview) — DONE
40. SEO score (title, description, tags presence) — DONE
41. Saved notes per channel/video — DONE
42. CSV export (combined dashboard, download from All Tools page) — DONE

## Deliberately NOT included (and why)
- AI thumbnail generation, a 122M-channel private niche database, sponsorship analysis from a private database, MCP/n8n automation: these are Nexlev's private paid services. They cannot be rebuilt from public data, and faking them would be dishonest. The template-based title/hashtag tools and public-data niche analysis above are the honest equivalents.
- Downloading YouTube videos: not included — it breaks YouTube's terms.
- Placing ads on other people's videos: not included — only a channel owner can do that, via official Studio APIs with their own login.
- Private analytics for channels you do not own: not available to anyone, including Nexlev (it says it does not access private channel information). This extension never invents it.

## Account (new in v2.1, on top of the 42 tools)
- Log in / Sign up — DONE, local only: email + name + password, password hashed with SHA-256 on your device before storage, no plain password saved, no server, no account sent anywhere. Login is optional — tools work without it.
- Sign in with Google — OPTIONAL, own Client ID only: uses Chrome identity if you add your own OAuth Client ID to manifest.json under "oauth2". Without that, it shows a clear setup message instead of pretending to log in. Never a secret in code.

## Monetization: free with ads (v2.2)
- All 42 tools free, no paywall. Revenue comes from ads, not from charging users.
- Ad slots: popup (bottom) and All Tools page (top + bottom), labelled “Sponsored — Foxyou is free with ads”, rotating house ads only in this build.
- No ads injected into YouTube pages. No third-party tracking in this build.
